//
//  FullScreenViewController.m
//  FullScreenDemo
//
//  Created by 王巍栋 on 2018/6/17.
//  Copyright © 2018年 骚栋. All rights reserved.
//

#import "FullScreenViewController.h"

#define KmainWidth  [UIScreen mainScreen].bounds.size.width

#define KmainHeight  [UIScreen mainScreen].bounds.size.height

@interface FullScreenViewController ()

@property(nonatomic,strong)UILabel *playView;
@property(nonatomic,assign)BOOL isFullScreen;//是否是全屏,减少动画执行次数
@property(nonatomic,assign)BOOL isPortraitFinished;//是否已经完成了竖屏.

@end

@implementation FullScreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.playView];
    self.isPortraitFinished = YES;//这个要开始设置为YES,不管在横屏还是竖屏的情况下都可以适应.
    //注册横竖屏的通知
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(rotateScreenViews:)
                                                 name:UIDeviceOrientationDidChangeNotification
                                               object:nil];
}

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];

    if ([[UIDevice currentDevice] respondsToSelector:@selector(setOrientation:)]) {
        SEL selector = NSSelectorFromString(@"setOrientation:");
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:[UIDevice instanceMethodSignatureForSelector:selector]];
        [invocation setSelector:selector];
        [invocation setTarget:[UIDevice currentDevice]];
        int val = UIInterfaceOrientationPortrait;
        [invocation setArgument:&val atIndex:2];
        [invocation invoke];
    }
}

//假设有上一级的页面 我们通过下面代码来进行竖屏切换,如果没有 去掉就好
- (void)viewWillDisappear:(BOOL)animated{
    
    [super viewWillDisappear:animated];

    if ([[UIDevice currentDevice] respondsToSelector:@selector(setOrientation:)]) {
        SEL selector = NSSelectorFromString(@"setOrientation:");
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:[UIDevice instanceMethodSignatureForSelector:selector]];
        [invocation setSelector:selector];
        [invocation setTarget:[UIDevice currentDevice]];
        int val = UIInterfaceOrientationPortrait;
        [invocation setArgument:&val atIndex:2];
        [invocation invoke];
    }
}

- (UILabel *)playView{
    
    if (_playView == nil) {
        _playView = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, KmainWidth, KmainWidth/16.0*9)];
        _playView.backgroundColor = [UIColor lightGrayColor];
        _playView.text = @"播放内容";
        _playView.font = [UIFont systemFontOfSize:18];
        _playView.textAlignment = NSTextAlignmentCenter;
    }
    return _playView;
}

#pragma mark - 屏幕旋转的主要动画操作方法

- (void)rotateScreenViews:(NSObject *)sender{

    UIDevice* device = [sender valueForKey:@"object"];
    
    if (device.orientation == UIDeviceOrientationPortrait && _isFullScreen) {
        CGFloat duration = [UIApplication sharedApplication].statusBarOrientationAnimationDuration;//时间
        _isFullScreen = NO;
        [UIView animateWithDuration:duration animations:^{
            CGFloat nowWidth = 0;
            if (KmainWidth > KmainHeight) {
                nowWidth = KmainHeight;
            }else{
                nowWidth = KmainWidth;
            }
            NSLog(@"竖进行");
            self.playView.frame = CGRectMake(0, 0, nowWidth, nowWidth/16.0*9);
            self.isPortraitFinished = NO;
        } completion:^(BOOL finished) {
            NSLog(@"竖完成");
            self.isPortraitFinished = YES;
            [self portraitFinishaNextAction];
            
        }];
        
    }
    
    if (device.orientation == UIDeviceOrientationLandscapeLeft && !_isFullScreen) {
        CGFloat duration = [UIApplication sharedApplication].statusBarOrientationAnimationDuration;//时间
        _isFullScreen = YES;
        [UIView animateWithDuration:duration animations:^{
            if (self.isPortraitFinished != NO) {
                self.playView.frame = CGRectMake(0, 0, KmainWidth, KmainHeight);
                NSLog(@"左右进行");
            }
        }completion:^(BOOL finished) {
            NSLog(@"左右完成");
        }];
    }
    if (device.orientation == UIDeviceOrientationLandscapeRight && !_isFullScreen) {
        CGFloat duration = [UIApplication sharedApplication].statusBarOrientationAnimationDuration;//时间
        _isFullScreen = YES;
        [UIView animateWithDuration:duration animations:^{
            if (self.isPortraitFinished != NO) {
                self.playView.frame = CGRectMake(0, 0, KmainWidth, KmainHeight);
                NSLog(@"左右进行");
            }
        } completion:^(BOOL finished) {
        }];
    }
}

//竖屏完成之后判断现在的手机设备的方向,如果是横竖屏,那么需要再次进行动画操作.
-(void)portraitFinishaNextAction{
    UIDeviceOrientation  orient = [UIDevice currentDevice].orientation;
    
    if (orient == UIDeviceOrientationLandscapeLeft || orient == UIDeviceOrientationLandscapeRight) {
        CGFloat duration = [UIApplication sharedApplication].statusBarOrientationAnimationDuration;//时间
        
        [UIView animateWithDuration:duration delay:duration options:UIViewAnimationOptionLayoutSubviews animations:^{
            
            if (self.isPortraitFinished != NO) {
                self.playView.frame = self.playView.frame;
            }
        } completion:^(BOOL finished) {
            self.playView.frame = CGRectMake(0, 0, KmainWidth, KmainHeight);
        }];
    }
}

- (void)dealloc{

    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIDeviceOrientationDidChangeNotification
                                                  object:nil];
    [[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];
}

@end
