//
//  AppDelegate.h
//  FullScreenDemo
//
//  Created by 王巍栋 on 2018/6/17.
//  Copyright © 2018年 骚栋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

